from aiogram.filters import BaseFilter
from aiogram.types import Message
from config import admin_id
from app.database.bot_base import get_user_base

class IsAdmin(BaseFilter):
    async def __call__(self, message: Message) -> bool:
        if message.from_user.id == admin_id:
            return True
        user = get_user_base(message.from_user.id)
        return user is not None and (user.get('is_admin') or user.get('is_staff'))
