def act_1_lang():
    text = "👋<b>Botimizga</b> xush kelibsiz"
    return text

def act_2_lang():
    text = "<b>👔Admin panelga hush kelibsiz !</b>"
    return text

def act_3_lang():
    text = "🔘Sizda hali guruhlar mavjud emas !"
    return text

def act_4_lang():
    text = "<b>📌Kerakli guruhni tanlang 👇🏻</b>"
    return text

def act_5_lang(name):
    text = f"💬<b>{name}</b> - guruhi <b>\n\n🗒Kerakli bo'limni tanlang 👇🏻</b>"
    return text

