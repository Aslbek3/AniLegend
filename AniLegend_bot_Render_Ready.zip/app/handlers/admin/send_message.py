from aiogram import F, Router
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from app.database.bot_base import *
from app.keyboards.admin.inline_buttons import *
from aiogram.enums import ParseMode
import asyncio
import random
from app.keyboards.admin.keyboard_buttons import *
from app.funcs.filters.chat_filter import ChatTypeFilter
from aiogram.exceptions import TelegramRetryAfter, TelegramForbiddenError, TelegramBadRequest

send_message_router = Router()

class Admin(StatesGroup):
    menu = State()

class Send_message(StatesGroup):
    type = State()
    type1 = State()
    type2 = State()

@send_message_router.message(ChatTypeFilter(chat_type=["group", "supergroup"]))
async def action(msg: Message, state: FSMContext):
    pass

@send_message_router.callback_query(F.data.startswith('c'), Send_message())
async def action(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await state.set_state(Admin.menu)
    await call.message.answer("✅<b>Bekor qilindi</b>", parse_mode=ParseMode.HTML, reply_markup=act_2_btn())
    await call.message.delete()

@send_message_router.callback_query(F.data.startswith('s'), Send_message.type)
async def action(call: CallbackQuery, state: FSMContext):
    command = call.data.split(",")[1]
    if command == "type1":
        await state.set_state(Send_message.type1)
        a = await call.message.edit_text("<b>⚠️Yuborilishi kerak bo'lgan habarni kiriting:</b>", parse_mode=ParseMode.HTML, reply_markup=act_1_clbtn())
        await state.update_data(message_id=a.message_id)
    elif command == "type2":
        await state.set_state(Send_message.type2)
        a = await call.message.edit_text("<b>⚠️Uztilishi kerak bo'lgan habarni kiriting:</b>", parse_mode=ParseMode.HTML, reply_markup=act_1_clbtn())
        await state.update_data(message_id=a.message_id)

async def safe_send(msg: Message, user_id: int, method_name: str, **kwargs):
    try:
        method = getattr(msg.bot, method_name)
        await method(chat_id=user_id, **kwargs)
        return True
    except TelegramRetryAfter as e:
        await asyncio.sleep(e.retry_after)
        return await safe_send(msg, user_id, method_name, **kwargs)
    except (TelegramForbiddenError, TelegramBadRequest):
        return False
    except Exception:
        return False

@send_message_router.message(Send_message.type1)
async def action(msg: Message, state: FSMContext):
    data = await state.get_data()
    message_id = data.get("message_id")
    users = get_all_user_id_base()
    
    await state.clear()
    await state.set_state(Admin.menu)
    await msg.answer(f"<b>✅Habar yuborilishi boshlandi</b>\n<i>{len(users)} ta foydalanuvchiga yuboriladi⚠️</i>", 
                     parse_mode=ParseMode.HTML, reply_markup=act_2_btn())

    try:
        await msg.bot.delete_message(chat_id=msg.from_user.id, message_id=message_id)
    except:
        pass

    sended = 0
    not_sended = 0
    
    # Determine method and base kwargs
    method_name = "send_message"
    kwargs = {"reply_markup": msg.reply_markup}
    
    if msg.text:
        method_name = "send_message"
        kwargs.update({"text": msg.text, "entities": msg.entities})
    elif msg.photo:
        method_name = "send_photo"
        kwargs.update({"photo": msg.photo[-1].file_id, "caption": msg.caption, "caption_entities": msg.caption_entities})
    elif msg.video:
        method_name = "send_video"
        kwargs.update({"video": msg.video.file_id, "caption": msg.caption, "caption_entities": msg.caption_entities})
    elif msg.animation:
        method_name = "send_animation"
        kwargs.update({"animation": msg.animation.file_id, "caption": msg.caption, "caption_entities": msg.caption_entities})
    elif msg.document:
        method_name = "send_document"
        kwargs.update({"document": msg.document.file_id, "caption": msg.caption, "caption_entities": msg.caption_entities})
    elif msg.audio:
        method_name = "send_audio"
        kwargs.update({"audio": msg.audio.file_id, "caption": msg.caption, "caption_entities": msg.caption_entities})
    elif msg.voice:
        method_name = "send_voice"
        kwargs.update({"voice": msg.voice.file_id, "caption": msg.caption, "caption_entities": msg.caption_entities})
    elif msg.sticker:
        method_name = "send_sticker"
        kwargs.update({"sticker": msg.sticker.file_id})
    else:
        # Fallback for other types or complex media groups (simplified here)
        method_name = "copy_message"
        kwargs = {"from_chat_id": msg.chat.id, "message_id": msg.message_id}

    for i, user in enumerate(users):
        res = await safe_send(msg, user['user_id'], method_name, **kwargs)
        if res:
            sended += 1
        else:
            not_sended += 1
        
        # Anti-flood: 30 messages per second limit by Telegram
        if i % 25 == 0:
            await asyncio.sleep(1)

    await msg.answer(f"<b>♻️Habar yuborib bo'lindi !</b>\n<i>✅Yuborildi: {sended} ta</i>\n<i>❌Yuborilmadi: {not_sended} ta</i>", 
                     parse_mode=ParseMode.HTML)

@send_message_router.message(Send_message.type2)
async def action(msg: Message, state: FSMContext):
    data = await state.get_data()
    message_id = data.get("message_id")
    users = get_all_user_id_base()
    
    try:
        await msg.bot.delete_message(chat_id=msg.from_user.id, message_id=message_id)
    except:
        pass

    await state.clear()
    await state.set_state(Admin.menu)
    await msg.answer(f"<b>✅Habar uzatilishi boshlandi</b>\n<i>{len(users)} ta foydalanuvchiga yuboriladi⚠️</i>", 
                     parse_mode=ParseMode.HTML, reply_markup=act_2_btn())

    sended = 0
    not_sended = 0
    for i, user in enumerate(users):
        res = await safe_send(msg, user['user_id'], "forward_message", from_chat_id=msg.chat.id, message_id=msg.message_id)
        if res:
            sended += 1
        else:
            not_sended += 1
        
        if i % 25 == 0:
            await asyncio.sleep(1)

    await msg.answer(f"<b>♻️Habar yuborib bo'lindi !</b>\n<i>✅Yuborildi: {sended} ta</i>\n<i>❌Yuborilmadi: {not_sended} ta</i>", 
                     parse_mode=ParseMode.HTML)
