import sqlite3
from datetime import *
from difflib import SequenceMatcher
import json

conn = sqlite3.connect('app/database/database.db', check_same_thread=False)
cursor = conn.cursor()

def add_user_base(user_id, username, lang="uz", is_admin=False, is_staff=False):
    cursor.execute('INSERT OR IGNORE INTO users (user_id, username, lang, is_admin, is_staff) VALUES (?, ?, ?, ?, ?);', 
                   (user_id, username, lang, is_admin, is_staff))
    update_statistics_user_count_base()
    conn.commit()

def add_media_base(trailer_id, name, genre, tag, dub, series=0, status="loading", views=0, msg_id=0, type="anime"):
    cursor.execute('INSERT INTO media (trailer_id, name, genre, tag, dub, series, status, views, msg_id, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);', 
                   (trailer_id, name, genre, tag, dub, series, status, views, msg_id, type))
    
    if type == "anime":
        cursor.execute('UPDATE statistics SET anime_count = anime_count + 1 WHERE bot = "bot"')
    else:
        cursor.execute('UPDATE statistics SET drama_count = drama_count + 1 WHERE bot = "bot"')

    conn.commit()
    return cursor.lastrowid

def add_episode_base(which_media, episode_id, episode_num, msg_id):
    cursor.execute('INSERT INTO episodes (which_media, episode_id, episode_num, msg_id) VALUES (?, ?, ?, ?);', 
                   (which_media, episode_id, episode_num, msg_id))
    conn.commit()
    return cursor.lastrowid

def add_sponsor_base(channel_id, channel_name, channel_link, type, user_limit):
    cursor.execute('INSERT INTO sponsors (channel_id, channel_name, channel_link, type, user_limit) VALUES (?, ?, ?, ?, ?);', 
                   (channel_id, channel_name, channel_link, type, user_limit))
    conn.commit()
    return cursor.lastrowid

def add_sponsor_request_base(channel_id, user_id):
    data = get_sponsor_request_base(channel_id, user_id)
    if not data:
        cursor.execute('INSERT INTO sponsor_request (chat_id, user_id) VALUES (?, ?);', (channel_id, user_id))
        conn.commit()

        sponsor = get_single_sponsors_base(channel_id)
        if sponsor:
            sponsor_limit = sponsor['user_limit'] - 1
            if sponsor_limit <= 0:
                delete_sponsor_base(channel_id)
            else:
                update_sponsor_limit_count_minus_base(channel_id)

# ==============================================================================

def get_sponsor_request_base(channel_id, user_id):
    cursor.execute("SELECT * FROM sponsor_request WHERE user_id = ? AND chat_id = ?", (user_id, channel_id))
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchone()
    return dict(zip(columns, data)) if data else None

def get_user_base(user_id):
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchone()
    return dict(zip(columns, data)) if data else None

def get_all_user_id_base():
    cursor.execute("SELECT user_id FROM users")
    data = cursor.fetchall()
    return [{"user_id": row[0]} for row in data] if data else []

def get_all_ongoing_media_base():
    cursor.execute("SELECT * FROM media WHERE status = 'loading'")
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchall()
    return [dict(zip(columns, row)) for row in data] if data else []

def get_all_media_base(type):
    cursor.execute("SELECT * FROM media WHERE type = ?", (type,))
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchall()
    return [dict(zip(columns, row)) for row in data] if data else []

def search_media_base(name, type):
    if type == "any":
        cursor.execute("SELECT * FROM media WHERE name LIKE ?", (f"%{name}%",))
    else:
        cursor.execute("SELECT * FROM media WHERE name LIKE ? AND type = ?", (f"%{name}%", type))
        
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchall()
    
    if not data:
        if type == "any":
            cursor.execute("SELECT * FROM media")
        else:
            cursor.execute("SELECT * FROM media WHERE type = ?", (type,))

        all_data = cursor.fetchall()
        media = [dict(zip(columns, row)) for row in all_data]

        def similar(a, b):
            return SequenceMatcher(None, a, b).ratio()

        new_data = []
        for i in media:
            similarity = similar(i["name"].lower(), name.lower())
            if similarity >= 0.4:
                new_data.append([similarity, i])
            else:
                try:
                    tags = i["tag"].split(",")
                    for tag in tags:
                        tag_similarity = similar(tag.strip().lower(), name.lower())
                        if tag_similarity >= 0.5:
                            new_data.append([tag_similarity, i])
                            break
                except:
                    pass
        
        new_data.sort(reverse=True, key=lambda x: x[0])
        return [i[1] for i in new_data]
    else:
        return [dict(zip(columns, row)) for row in data]

def get_media_base(media_id):
    cursor.execute("SELECT * FROM media WHERE media_id = ?", (media_id,))
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchone()
    return dict(zip(columns, data)) if data else None

def get_media_episodes_base(media_id):
    cursor.execute("SELECT * FROM episodes WHERE which_media = ? ORDER BY episode_num ASC", (media_id,))
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchall()
    return [dict(zip(columns, row)) for row in data] if data else []

def get_statistics_base():
    cursor.execute("SELECT * FROM statistics WHERE bot = 'bot'")
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchone()
    return dict(zip(columns, data)) if data else None

def get_all_sponsors_base():
    cursor.execute("SELECT * FROM sponsors")
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchall()
    return [dict(zip(columns, row)) for row in data] if data else []

def get_single_sponsors_base(channel_id):
    cursor.execute("SELECT * FROM sponsors WHERE channel_id = ?", (channel_id,))
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchone()
    return dict(zip(columns, data)) if data else None

def get_all_staff_base():
    cursor.execute("SELECT * FROM users WHERE is_staff = 1")
    columns = [desc[0] for desc in cursor.description]
    data = cursor.fetchall()
    return [dict(zip(columns, row)) for row in data] if data else []

# ==============================================================================

def update_statistics_user_count_base():
    cursor.execute('UPDATE statistics SET users_count = users_count + 1 WHERE bot = "bot"')
    conn.commit()

def update_media_episodes_count_plus_base(media_id):
    cursor.execute('UPDATE media SET series = series + 1 WHERE media_id = ?', (media_id,))
    conn.commit()

def update_media_episodes_count_minus_base(media_id):
    cursor.execute('UPDATE media SET series = series - 1 WHERE media_id = ?', (media_id,))
    conn.commit()

def update_media_name_base(media_id, name):
    cursor.execute('UPDATE media SET name = ? WHERE media_id = ?', (name, media_id))
    conn.commit()

def update_media_genre_base(media_id, genre):
    cursor.execute('UPDATE media SET genre = ? WHERE media_id = ?', (genre, media_id))
    conn.commit()

def update_media_tag_base(media_id, tag):
    cursor.execute('UPDATE media SET tag = ? WHERE media_id = ?', (tag, media_id))
    conn.commit()

def update_media_dub_base(media_id, dub):
    cursor.execute('UPDATE media SET dub = ? WHERE media_id = ?', (dub, media_id))
    conn.commit()

def update_media_vip_base(media_id, is_vip):
    cursor.execute('UPDATE media SET is_vip = ? WHERE media_id = ?', (is_vip, media_id))
    conn.commit()

def update_media_status_base(media_id, status):
    cursor.execute('UPDATE media SET status = ? WHERE media_id = ?', (status, media_id))
    conn.commit()

def update_episode_base(media_id, episode_num, episode_id):
    cursor.execute('UPDATE episodes SET episode_id = ? WHERE which_media = ? AND episode_num = ?', (episode_id, media_id, episode_num))
    conn.commit()

def update_user_staff_base(user_id, value):
    cursor.execute('UPDATE users SET is_staff = ? WHERE user_id = ?', (value, user_id))
    conn.commit()

def update_sponsor_limit_count_minus_base(channel_id):
    cursor.execute('UPDATE sponsors SET user_limit = user_limit - 1 WHERE channel_id = ?', (channel_id,))
    conn.commit()

# ==============================================================================

def delete_episode_base(media_id, episode_num):
    cursor.execute('DELETE FROM episodes WHERE which_media = ? AND episode_num = ?', (media_id, episode_num))
    conn.commit()

def delete_sponsor_base(channel_id):
    cursor.execute('DELETE FROM sponsors WHERE channel_id = ?', (channel_id,))
    cursor.execute('DELETE FROM sponsor_request WHERE chat_id = ?', (channel_id,))
    conn.commit()
