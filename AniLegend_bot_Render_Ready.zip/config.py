# Serveringizga python yordamida requirements.txt faylini install qiling

#-----------------------------------------------
# Telegramda yopiq kanal oching. 
# Kanal nomini "Trailers" nomiga o'zgartiring. Botingizni yopiq kanalga admin qiling va 
# o'sha yopiq kanalingiz ID sini shu yerga yozing
trailers_base_chat = -1003471150905 

#-----------------------------------------------
# Telegramda yopiq kanal oching. 
# Kanal nomini "Series" nomiga o'zgartiring. Botingizni yopiq kanalga admin qiling va 
# o'sha yopiq kanalingiz ID sini shu yerga yozing
series_base_chat = -1003471150905 

#----------------------------------------------- 
# @botfather orqali bot yaratib botingizni tokenini shu yerga yozib qo'ying
token = "8012951804:AAFmcyU4LxRMkRzSPBuGIlIB_ZsMeFcNT4M" 

#-----------------------------------------------
# Botingizni Usernamesini "@" belgisini qo'ymagan holda shu yerga yozib qo'ying. 
bot_username = "AniLegend_bot" # O'zgartirishingiz mumkin

#-----------------------------------------------
# Foydalanuvchilar reklama yuzasidan 
# bo'g'lana olishlari uchun telegram akkuntingizni usernamesini "@" belgisini qo'ymagan holda shu yerga yozib qo'ying
ads_manager_username = "Aslbek_1203"

#-----------------------------------------------
# Asosiy admin ID si
admin_id = 7586510077
